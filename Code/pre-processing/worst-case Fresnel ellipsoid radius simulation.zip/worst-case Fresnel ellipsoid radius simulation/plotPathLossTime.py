from matplotlib.pyplot import plot, show, legend, title, xlabel, ylabel, suptitle, xticks, yticks
from typeguard import List, Dict, Any, TextIO, Union
from scipy import interpolate
from math import log10, pow
from operator import add


# Import functions taken from: https://github.com/signetlabdei/rt-blockage-manager
# Paper: P. Testolina, et al., "An Open Framework to Model Diffraction by Dynamic Blockers in
# Millimiter Wave Simulations," in IEEE 20th Med. Commun. Computer Netw. Conf. (MedComNet), Jun. 2022.


def _get_next_row_floats(file: TextIO, n_rays: int) -> List[float]:
    line = file.readline()
    assert line != '', f"Unexpected EOF for file {file.name}"

    floats = [float(x) for x in line.split(',')]
    assert len(
        floats) == n_rays, f"Expected {n_rays} entries, found {len(floats)}"

    return floats


def import_qd_file(path: str) -> List[Dict[str, Any]]:
    with open(path, 'rt') as f:
        line = f.readline()

        qd_file = []
        while line != '':  # EOF='' in python
            n_rays = int(line)
            rays: Dict[str, Union[int, List[float]]] = {'n_rays': n_rays}

            if n_rays > 0:
                rays = {**rays,  # add to dict
                        'delay': _get_next_row_floats(f, n_rays),  # [s]
                        'path_gain': _get_next_row_floats(f, n_rays),  # [dB]
                        'phase_offset': _get_next_row_floats(f, n_rays),  # [rad]
                        'aod_el': _get_next_row_floats(f, n_rays),  # [deg]
                        'aod_az': _get_next_row_floats(f, n_rays),  # [deg]
                        'aoa_el': _get_next_row_floats(f, n_rays),  # [deg]
                        'aoa_az': _get_next_row_floats(f, n_rays)}  # [deg]

            qd_file.append(rays)

            # read next line
            line = f.readline()

    return qd_file


def calculate_array_all_pos(start_value, increment, num_elements):
    return [int(abs(start_value + i * increment)) for i in range(num_elements)]


def interpolate_list(values, indices, n):

    zero_index = values.index(0)

    # Create an interpolation function based on the original lists
    f = interpolate.interp1d(indices, values)

    # Create a new list of indices with a maximum of n elements
    new_indices = list(range(min(indices), max(indices), max(1, len(indices) // n)))

    # Use the interpolation function to calculate the new values
    new_values = f(new_indices).tolist()
    new_values = list(map(int, new_values))

    try:
        new_values.index(0)
        return new_values, new_indices

    except ValueError:
        new_values.append(0)
        new_indices.append(zero_index)
        return new_values, new_indices


# MPC ray summing, db->value->db conversion: R. Schulpen, et al., "Impact of Human Blockage on Dynamic Indoor
# Multipath Channels at 27 GHz," in IEEE Trans. Antennas Propagation, vol. 70, no. 9, pp. 8291-8303, Sept. 2022.

f_paths = [r'C:\TUe-PhD\UT-RS-3 Domain-Invariant Beam Adaptivity\worst-case Fresnel ellipsoid radius simulation\rt-blockage-manager\scenarios\Indoor1\BlockageOut_ITU_SE\Output\Ns3\QdFiles\Tx0Rx1.txt',
           r'C:\TUe-PhD\UT-RS-3 Domain-Invariant Beam Adaptivity\worst-case Fresnel ellipsoid radius simulation\rt-blockage-manager\scenarios\Indoor1\BlockageOut_METIS\Output\Ns3\QdFiles\Tx0Rx1.txt',
           r'C:\TUe-PhD\UT-RS-3 Domain-Invariant Beam Adaptivity\worst-case Fresnel ellipsoid radius simulation\rt-blockage-manager\scenarios\Indoor1\BlockageOut_DKED\Output\Ns3\QdFiles\Tx0Rx1.txt',
           r'C:\TUe-PhD\UT-RS-3 Domain-Invariant Beam Adaptivity\worst-case Fresnel ellipsoid radius simulation\rt-blockage-manager\scenarios\Indoor1\BlockageOut_DKED_PC\Output\Ns3\QdFiles\Tx0Rx1.txt']
path_gain_normal_values = []

for f_path in f_paths:

    rayDict_per_time_instant = import_qd_file(f_path)
    path_gain_normal_value = [0 for i in range(0, len(rayDict_per_time_instant))]

    for i in range(0, len(rayDict_per_time_instant[0]['path_gain'])):

        path_gain_normal_value = list(map(add, path_gain_normal_value, [
            pow(10.0, x['path_gain'][i] / 10.0) for x in rayDict_per_time_instant]))

    path_gain_normal_value = [-10 * log10(x) - 72 for x in path_gain_normal_value]
    path_gain_normal_values.append(path_gain_normal_value)

default_x_values = list(range(0, 1500))

for name, array in zip(['ITU_SE', 'METIS', 'DKED', 'DKED_PC'], path_gain_normal_values):

    print(max(array), min(array))
    plot(default_x_values, array, label=name)

distance_los = calculate_array_all_pos(350, -0.4, 1500)
obstruction_array = [78 -72 if x <= 11 else 72 - 72 for x in distance_los]
baseline_array = [72 - 72 for _ in distance_los]
plot(default_x_values, obstruction_array, label='Obstruction')
plot(default_x_values, baseline_array, label='Baseline')

title('NIST Q-D Ray Channel Gain Loss', fontsize=18)
xlabel('Distance to direct LoS (cm)', fontsize=16)
ylabel('Diffraction Loss (dB)', fontsize=16)
legend(loc="upper right", fontsize=12)
offset_distance_los, offset_default_x_values = interpolate_list(distance_los, default_x_values, 12)
xticks(offset_default_x_values, offset_distance_los, fontsize=12)
yticks(fontsize=12)
show()
