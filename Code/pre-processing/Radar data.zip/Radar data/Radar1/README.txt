Unpack the .bin files of Radar data.zip from https://doi.org/10.4121/22117145 in this directory
